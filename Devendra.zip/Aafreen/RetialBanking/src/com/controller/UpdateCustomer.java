package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.DAO.user;
import com.bean.Customer;
import com.util.DbTransaction;

/**
 * Servlet implementation class Update
 */
@WebServlet("/UpdateCustomer")
public class UpdateCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		int customer_id=Integer.parseInt(request.getParameter("customer_id")); 
		String customer_name=request.getParameter("customer_name");
		String password=request.getParameter("password");
		String dob=request.getParameter("dob");
		String address_line1=request.getParameter("address_line1");
		String address_line2=request.getParameter("address_line2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		
		System.out.println(customer_id+" "+customer_name+" "+password+" "+dob+" "+address_line1+" "+address_line2+" "+city+" "+state);
		Customer c=new Customer();
		c.setCustomer_id(customer_id);
		c.setCustomer_name(customer_name);
		c.setPassword(password);
		c.setDob(dob);
		c.setAddress_line1(address_line1);
		c.setAddress_line2(address_line2);
		c.setCity(city);
		c.setState(state);
		int status=user.update(c);
		if(status>0)
		{
			request.setAttribute("status", 1);
			request.getRequestDispatcher("updateUser.jsp").forward(request, response);
		}
		else
		{ 
			 out.println("Sorry! unable to update record");  
		}
		 out.close();
	
	}
}


	

	


