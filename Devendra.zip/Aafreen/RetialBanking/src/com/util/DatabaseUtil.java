package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseUtil {

	private static final String DRIVERNAME="oracle.jdbc.driver.OracleDriver";
	private static final String URL="jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP";
	private static final String USERNAME="aja38core";
	private static final String PASSWORD="aja38core";
	
	//table names
	public static final String tbl_customer="tbl_Customer_G3_A";//"tbl_customer_G3";
	public static final String tbl_customer_login="tbl_customer_login_G3_A";
	public static final String tbl_account="TBL_ACCOUNT_G3_A";
	public static final String tbl_transaction="TBL_TRANSACTIONS_G3_A";
	public static final String tbl_employee="tbl_employee_G3";
	public static final String tbl_employee_login="tbl_employee_login_G3";
	
	
	
	public static Connection getConnection(){
		
		Connection con=null;
		try {
			Class.forName(DRIVERNAME);
			con=DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		return con;
		
		
	
	}
	

	
	public static void closeStatement(PreparedStatement ps){
		
		if(ps!=null){
			
			try {
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
		}
		
		
	}
	
	
	
	public static void closeConnection(Connection  con){
		
		if(con!=null){
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
		}
		
		
	}
	
	

}
