package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.util.DbTransaction;


public class UpdateCustomer {
	public ResultSet ViewCustomer(DbTransaction db,int ssn) throws SQLException
	{
		PreparedStatement st1=null;
		String query=null;
		Connection conn=null;
		ResultSet rs = null;
		
		conn = db.getConnection();
		query ="select * from tbl_Customer_G3 where SSN="+ssn;
	    st1 =conn.prepareStatement(query);
	    rs = st1.executeQuery();
		return rs;
	}

}
