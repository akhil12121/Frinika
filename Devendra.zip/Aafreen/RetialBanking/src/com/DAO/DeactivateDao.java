package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.util.DbTransaction;

public class DeactivateDao {
	public int DeactivateStatus (DbTransaction db) throws SQLException {
		   Connection conn = null;
		   PreparedStatement stmt = null;
		   try{
			    conn= db.getConnection();
		        String sql = "UPDATE tbl_customer_g3 SET Status = "+"'Deactivate'";
		       
			    stmt =conn.prepareStatement(sql);
				int result=stmt.executeUpdate(sql);
			 
		        if(result>0)
		        {
		        	return 1;
		        }
		   }
			catch (Exception e)
			{
				System.out.println(e);
			}
			finally{
				conn.close();
			}
			
		
			return 0;
			
	        }
		   

}

	


