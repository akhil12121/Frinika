package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.WrongLoginAttempt;
import com.util.DatabaseUtil;

public class EmployeeLogin implements Int_EmployeeLogin {

	public boolean validateLogin(String userId, String password) {
		int count = 0;
		Connection con = null;
		PreparedStatement ps = null;
		String query = "select * from " + DatabaseUtil.tbl_employee_login + " where user_id=? and password=?";
		try {
			con = DatabaseUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, userId);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				count++;
			}

			if (count > 0)
				return true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public static String getEmployeeType(String userId) {
		Connection con = null;
		PreparedStatement ps = null;
		String query = "select type from " + DatabaseUtil.tbl_employee + " t1, " + DatabaseUtil.tbl_employee_login
				+ " t2 where t1.id=t2.id and t2.user_id=?";
		System.out.println(query);
		try {
			con = DatabaseUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, userId);
			ResultSet rs = ps.executeQuery();

			rs.next();
			return rs.getString(1);

		} catch (SQLException e) {
			return "-1";
		}
	}

	public boolean isLoggedIn(String userId) {
		// TODO Auto-generated method stub
		return false;
	}

	public WrongLoginAttempt getWrongLoginAttempt(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
