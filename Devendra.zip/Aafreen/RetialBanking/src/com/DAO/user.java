package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.bean.Customer;
import com.bean.Account;
import com.util.DatabaseUtil;

public class user {
	static Connection conn=null;
	static Statement st=null;
	static PreparedStatement pst=null;
	static ResultSet rs=null;
	public static ArrayList<Customer> searchUser(String ssn, String custNumber, String name)
	{
		ArrayList<Customer> result=new ArrayList<Customer>();
		Connection con = DatabaseUtil.getConnection();
		PreparedStatement ps = null;
		if (con != null) {
			try {
				String sql = "select * from "+ DatabaseUtil.tbl_customer +" where ssn like '%"+ssn+"%' AND ID like '%"+custNumber+"%' AND NAME like '%"+name+"%'";
				ps = con.prepareStatement(sql);
				//ps.setInt(1, ssn);

				ResultSet rs = ps.executeQuery();
				while(rs.next())
				{
					Customer c= new Customer();
					c.setCustomer_id(rs.getInt("ID"));
					c.setSSN(rs.getInt("SSN"));
					c.setCustomer_name(rs.getString("NAME"));
					c.setDob(rs.getString("dob"));
					c.setAddress_line1(rs.getString("ADDRESS_LINE1"));
					c.setAddress_line2(rs.getString("ADDRESS_LINE2"));
					c.setCity(rs.getString("CITY"));
					c.setState(rs.getString("STATE"));
					c.setStatus(rs.getString("status"));
			    	
			    	result.add(c);
				}

				return result;
			} catch (SQLException e) {
				System.out.println(e);
				return result;
			} finally {

				DatabaseUtil.closeStatement(ps);
				DatabaseUtil.closeConnection(con);
			}
		}
		return result;
	}
	public static int update(Customer c)
	{
		int status=0;
		try{
			conn=DatabaseUtil.getConnection();
			String query="update TBL_CUSTOMER_G3 set customer_name=?, password=?, dob=?, address_line1=?, address_line2=?, city=? ,state=? where customer_id=?";
			pst=conn.prepareStatement(query);
			
			pst.setString(1, c.getCustomer_name());
			pst.setString(2,c.getPassword());
			pst.setString(3, c.getDob());
			pst.setString(4,c.getAddress_line1());
			pst.setString(5, c.getAddress_line2());
			pst.setString(6, c.getCity());
			pst.setString(7, c.getState());
			pst.setInt(8, c.getCustomer_id());
			status=pst.executeUpdate();
		System.out.println(status);
		}catch(SQLException s)
		{
			s.printStackTrace();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
//		finally{
//			DatabaseUtil.closeConnection(conn);
//			DatabaseUtil.closeStatement(pst);
//		}
		return status;
	}
	
	public static ArrayList<String> getAccountsNumber(String userId)
	{
		ArrayList<String> result=new ArrayList<String>();
		if(userId==null || userId=="")
			return result;
		Connection con = DatabaseUtil.getConnection();
		PreparedStatement ps = null;
		if (con != null) {
			try {
				String sql = "select account_id from "+ DatabaseUtil.tbl_account +" where CUSTOMER_ID=?";
				ps = con.prepareStatement(sql);
				ps.setInt(1,Integer.parseInt(userId));
				//ps.setInt(1, ssn);

				ResultSet rs = ps.executeQuery();
				while(rs.next())
				{
					result.add(rs.getString(1));
				}

				return result;
			} catch (SQLException e) {
				System.out.println(e);
				return result;
			} finally {

				DatabaseUtil.closeStatement(ps);
				DatabaseUtil.closeConnection(con);
			}
		}
		return result;
	}
	
	public static Customer getCustomerDetails(String customerId, String accountId)
	{
		Connection con = DatabaseUtil.getConnection();
		PreparedStatement ps = null;
		
		Customer cus=new Customer();
//		if(customerId==null || customerId=="")
//		{
			if(accountId!=null && accountId!="")
			{
				String sql = "select CUSTOMER_ID from "+ DatabaseUtil.tbl_account +" where account_id=?";
				try {
					ps = con.prepareStatement(sql);
					ps.setInt(1,Integer.parseInt(accountId));

					ResultSet rs = ps.executeQuery();
					if(rs.next())
						customerId=rs.getString(1);
					else if(customerId==null || customerId=="")
						customerId="-1";
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}	
//		}
		
		if (con != null) {
			try {
				String sql = "select * from "+ DatabaseUtil.tbl_customer +" where id=?";
				ps = con.prepareStatement(sql);
				if(customerId==null || customerId=="")
					return null;
				ps.setInt(1,Integer.parseInt(customerId));
				
				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
					cus.setCustomer_id(rs.getInt(1));
					cus.setSSN(rs.getInt(2));
					cus.setCustomer_name(rs.getString(3));
					cus.setDob(rs.getString(4));
					cus.setAddress_line1(rs.getString(5));
					cus.setAddress_line2(rs.getString(6));
					cus.setCity(rs.getString(7));
					cus.setState(rs.getString(8));
					cus.setStatus(rs.getString(9));
				}
				else
				{
					return null;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {

				DatabaseUtil.closeStatement(ps);
				DatabaseUtil.closeConnection(con);
			}
		}
		return cus;
	}
	
	
	public static Account getAccountDetails(String accountId)
	{
		Account act=new Account();
		if(accountId==null || accountId=="")
			return null;
		Connection con = DatabaseUtil.getConnection();
		PreparedStatement ps = null;
		if (con != null) {
			try {
				String sql = "select * from "+ DatabaseUtil.tbl_account +" where account_id=?";
				ps = con.prepareStatement(sql);
				ps.setInt(1,Integer.parseInt(accountId));

				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
					act.setAccountId(rs.getInt(1));
					act.setAccountType(rs.getString(3));
					act.setAmount(rs.getInt(4));
					act.setCustomerId(rs.getInt(2));
					act.setCr_date(rs.getString(5));
					act.setCr_last_date(rs.getString(6));
					act.setDuration(rs.getString(7));
					return act;
				}
				else
					return null;
			} catch (SQLException e) {
				return null;
			} finally {

				DatabaseUtil.closeStatement(ps);
				DatabaseUtil.closeConnection(con);
			}
		}
		return null;
	}
	
	
}
