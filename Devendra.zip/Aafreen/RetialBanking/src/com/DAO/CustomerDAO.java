package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.Customer;
import com.util.DatabaseUtil;
import com.util.DbTransaction;

public class CustomerDAO {

	public ResultSet getAllCustomer() {
		PreparedStatement st1 = null;
		String query = null;
		Connection conn = null;
		ResultSet rs = null;

		conn = DatabaseUtil.getConnection();
		if (conn != null) {
			query = "select * from "+DatabaseUtil.tbl_customer;
			try {
				st1 = conn.prepareStatement(query);
				rs = st1.executeQuery();
				while(rs.next())
				{
					Customer c=new Customer();
					c.setCustomer_id(rs.getString(1));
					c
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		return rs;
	}

}
