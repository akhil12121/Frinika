package com.bean;

public class WrongLoginAttempt {
	private int Id;
	private String customerId;
	private String IP;
	private String location;
	private String loginAttemptDateTime;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getIP() {
		return IP;
	}
	public void setIP(String iP) {
		IP = iP;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getLoginAttemptDateTime() {
		return loginAttemptDateTime;
	}
	public void setLoginAttemptDateTime(String loginAttemptDateTime) {
		this.loginAttemptDateTime = loginAttemptDateTime;
	}
}
