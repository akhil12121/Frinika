package com.service;

import java.sql.ResultSet;

import com.DAO.Transfer;

public class Transfer_Service {

	
	
	public static ResultSet getAccount(String accountId)
	{
		return Transfer.getAccount(Integer.parseInt(accountId));
	}
	
	public static int Transfer_Amt(int accountId1,int accountId2,int amount,String description)
	{
		return Transfer.Transfer_Amt(accountId1, accountId2, amount,description);
	}
	
	
	public static int getCustomerId(int accountId1)
	{
		return Transfer.getCustomerId(accountId1);
	}
	
	public static int getAmount(int accountId)
	{
		return Transfer.getAmount(accountId);
	}
	
	public static String getAccountType(int accountId)
	{
		return Transfer.getAccountType(accountId);
	}
}
