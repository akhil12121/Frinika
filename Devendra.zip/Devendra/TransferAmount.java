package com.controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.Transfer_Service;

/**
 * Servlet implementation class TransferAmount
 */
@WebServlet("/TransferAmount")
public class TransferAmount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransferAmount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		int accountId1 = Integer.parseInt(request.getParameter("account_id"));
		//System.out.println(accountId1);
		
		int accountId2=Integer.parseInt(request.getParameter("account"));
		//System.out.println(accountId2);
		
		int amount=Integer.parseInt(request.getParameter("amount"));
		//System.out.println(amount);
		
		String description=request.getParameter("description");
		
		int account1_amt=Transfer_Service.getAmount(accountId1);
		
		int account2_amt=Transfer_Service.getAmount(accountId2);
		
		String Account1_type=Transfer_Service.getAccountType(accountId1);
		
		String Account2_type=Transfer_Service.getAccountType(accountId2);
		
		int transfer=Transfer_Service.Transfer_Amt(accountId1, accountId2, amount,description);
		
		//After Transfer new amount will be reflected in the database
		
		int account1_amt_new=Transfer_Service.getAmount(accountId1);
		
		int account2_amt_new=Transfer_Service.getAmount(accountId2);
		//System.out.println(""+transfer);
		
		if(transfer==-1)
		{
			request.setAttribute("result", -1);
			//System.out.println(request.getContextPath());
		request.getRequestDispatcher("/emp/Transfer_Amount.jsp").forward(request, response);
		}
		
		else{
			
			request.setAttribute("account_id_1", accountId1);
			request.setAttribute("account_id_2", accountId2);
			request.setAttribute("account1_amt", account1_amt);
			request.setAttribute("account2_amt", account2_amt);
			request.setAttribute("account1_amt_new", account1_amt_new);
			request.setAttribute("account2_amt_new", account2_amt_new);
			request.setAttribute("Account1_type", Account1_type);
			request.setAttribute("Account2_type", Account2_type);
			
			
			int customer_id=Transfer_Service.getCustomerId(accountId1);
			
			request.setAttribute("customer_id", customer_id);
			request.setAttribute("result", 1);
			//System.out.println(request.getContextPath());
		request.getRequestDispatcher("/emp/Transfer_Amount.jsp").forward(request, response);
		}
		
		
	}

}
