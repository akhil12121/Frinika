package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.DAO.CustomerLogin;
import com.service.CustomerService;
import com.service.Login;

/**
 * Servlet implementation class LoginCustomer
 */
@WebServlet("/ChangePassword")
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("In post");
		String currentPass=request.getParameter("userPassCurrent");
		String newPass=request.getParameter("userPassNew");
		
		String hash_pass1=Login.getHashPassword(currentPass);
		System.out.println(hash_pass1);
		CustomerLogin csLogin = new CustomerLogin();
		boolean check = csLogin.validateLoginCust("user1", hash_pass1);
		
		System.out.println(check);
		if(check){
			
			CustomerService custServiceObj = new CustomerService();
			String hash_pass2=Login.getHashPassword(newPass);
			
			try {
				boolean b = custServiceObj.changePasswordCustomer(hash_pass2, "user1");
				if(b)
				{
					request.setAttribute("successfull", b);
					RequestDispatcher rd= request.getRequestDispatcher("/dashboard.jsp");
					rd.forward(request, response);
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	


	}}
