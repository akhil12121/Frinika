package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.util.DatabaseUtil;

public class CustomerLogin {

	public boolean validateLoginCust(String customer_id, String customerPassword) {
		int count = 0;
		Connection con = null;
		PreparedStatement ps = null;
		
		System.out.println(customer_id);
		System.out.println(customerPassword);
		String query = "select * from "+ DatabaseUtil.tbl_customer_login +" where USER_ID=? and password=?";
		try {
			con = DatabaseUtil.getConnection();
			ps = con.prepareStatement(query);
			ps.setString(1, customer_id);
			ps.setString(2, customerPassword);
			ResultSet rs = ps.executeQuery();

			while(rs.next())
			{
				count++;
			}
				System.out.println(count);
			if (count > 0)
				return true;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	
}
