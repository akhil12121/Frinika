package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

import java.sql.SQLException;

import com.util.DatabaseUtil;


public class ChangePasswordCustomer {

	 public boolean changePasswordCustomer(String passwordNew, String customer_id) throws SQLException
	 {
		boolean flag = false;
		Connection conn=null;
		conn = DatabaseUtil.getConnection();
				 
		if(conn!=null){
						
		String query=null;
		PreparedStatement st1=null;
		int count = 0;
		query = "UPDATE "+ DatabaseUtil.tbl_customer_login +" SET PASSWORD = ? where USER_ID = ?";
				 
		st1 =conn.prepareStatement(query);
		st1.setString(1,passwordNew);
		st1.setString(2,customer_id);
		count = st1.executeUpdate();
		if(count > 0)
				flag = true;
							
					
				 
		}
		 return flag;
	 	}
		 
	 
	 }
