package com.service;

import java.sql.SQLException;

import com.DAO.ChangePasswordCustomer;
import com.DAO.CustomerDAO;


public class CustomerService {
	
	ChangePasswordCustomer changePassCust = new  ChangePasswordCustomer();
	
	public boolean activateCustomer(String customerId, String currentStatus)
	{
		return CustomerDAO.activateCustomer(customerId, currentStatus);
	}

	 public boolean changePasswordCustomer(String passwordNew, String customer_id) throws SQLException
	 {
		 return changePassCust.changePasswordCustomer(passwordNew, customer_id);
	 }

	
	public boolean loginCustomer(String customerId, String password)
	{
		return CustomerDAO.loginCustomer(customerId, password);
	}

}
