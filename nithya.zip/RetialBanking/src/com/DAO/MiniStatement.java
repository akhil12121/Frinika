package com.DAO;

public class MiniStatement {

	public int miniStatement()
	{
		return 0;
		
	}
}
