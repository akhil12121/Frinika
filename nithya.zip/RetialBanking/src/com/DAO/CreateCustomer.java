package com.DAO;
import java.util.*;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bean.Customer;
import com.service.Login;
import com.util.DatabaseUtil;
import com.util.DbTransaction;

public class CreateCustomer {

	public static boolean addCustomer(Customer c) throws SQLException
	{
		
		Connection con=DatabaseUtil.getConnection();
		PreparedStatement ps1=con.prepareStatement("SELECT count(*) from "+DatabaseUtil.tbl_customer+ " where ssn=?");
		ps1.setInt(1, c.getSSN());
		ResultSet rs=ps1.executeQuery();
		rs.next();
		if(rs.getInt(1)>0)
			return false;
		
		
		ps1=con.prepareStatement("SELECT count(*) from "+DatabaseUtil.tbl_customer_login+ " where user_id=?");
		ps1.setString(1, c.getUserId());
		rs=ps1.executeQuery();
		rs.next();
		if(rs.getInt(1)>0)
			return false;
		
		
		String sql1="insert into "+DatabaseUtil.tbl_customer+ " values(tbl_sequence_g3.nextval,?,?,?,?,?,?,?,'Active')";
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql1);
		ps.setInt(1, c.getSSN());
		ps.setString(2, c.getCustomer_name());
		ps.setString(3, c.getDob());
		ps.setString(4, c.getAddress_line1());
		ps.setString(5, c.getAddress_line2());
		ps.setString(6, c.getCity());
		ps.setString(7, c.getState());
		int x=ps.executeUpdate();
		
		String sql2="insert into "+DatabaseUtil.tbl_customer_login+ " values(tbl_sequence_g3.currval,?,?)";
		ps=con.prepareStatement(sql2);
		ps.setString(1, c.getUserId());
		ps.setString(2, Login.getHashPassword(c.getPassword()));
		
		int y=ps.executeUpdate();
		
		String sql3="insert into "+DatabaseUtil.tbl_customer_pic+ " values(tbl_sequence_g3.currval,'default.jpg')";
		ps=con.prepareStatement(sql3);
		
		ps.executeUpdate();
		
		if(x>0 && y>0)
			return true;
		return false;
	}
	
	public static ResultSet deleteCustomer(int customer_id) throws SQLException
	{
	Customer c = new Customer();
	System.out.println(c.getSSN());

		Connection con=DatabaseUtil.getConnection();
		String sql1="select * from tbl_Customer_G3 where customer_id=?";
		PreparedStatement ps=null;
		ps=con.prepareStatement(sql1);
		ps.setInt(1, customer_id);
		ResultSet rs1=ps.executeQuery();
		return rs1;
	}
}

