package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.util.DbTransaction;

public class ViewCustomersDao {
	
 public ResultSet view(DbTransaction db,int ssn) throws SQLException
 {
	 PreparedStatement st1=null;
		String query=null;
		Connection conn=null;
		ResultSet rs = null;
		

		conn = db.getConnection();
		if(conn!=null)
		{
		query ="select * from tbl_customer_g3 where SSN=?";
	    st1 =conn.prepareStatement(query);
	    st1.setInt(1,ssn);
	    rs = st1.executeQuery();
		}
		return rs;
	}
	 
 }


