package com.DAO;

import com.bean.WrongLoginAttempt;
import com.util.DbTransaction;

public interface Int_EmployeeLogin {
	public boolean validateLogin(String userId, String password);
	public boolean isLoggedIn(String userId);
	public WrongLoginAttempt getWrongLoginAttempt(String userId);
}
