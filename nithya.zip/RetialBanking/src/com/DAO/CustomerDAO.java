package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Customer;
import com.service.Login;
import com.util.DatabaseUtil;

public class CustomerDAO {

	public static ArrayList<Customer> getAllCustomer() {
		
		ArrayList<Customer> result=new ArrayList<Customer>();
		
		PreparedStatement st1 = null;
		String query = null;
		Connection conn = null;
		ResultSet rs = null;

		conn = DatabaseUtil.getConnection();
		if (conn != null) {
			query = "select * from "+DatabaseUtil.tbl_customer;
			try {
				st1 = conn.prepareStatement(query);
				rs = st1.executeQuery();
				while(rs.next())
				{
					Customer c=new Customer();
					c.setCustomer_id(rs.getInt(1));
					c.setSSN(rs.getInt(2));
					c.setCustomer_name(rs.getString(3));
					c.setDob(rs.getString(4));
					c.setAddress_line1(rs.getString(5));
					c.setAddress_line2(rs.getString(6));
					c.setCity(rs.getString(7));
					c.setState(rs.getString(8));
					c.setStatus(rs.getString(9));
					
					result.add(c);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	
	public static boolean activateCustomer(String customerId, String currentStatus)
	{
		PreparedStatement st1=null;
		String query=null;
		Connection conn=null;
		ResultSet rs = null;
		
		conn = DatabaseUtil.getConnection();
		if(currentStatus.equals("Active"))
			query = "UPDATE "+DatabaseUtil.tbl_customer+" SET status='Inactive' where id="+customerId;
		else
			query = "UPDATE "+DatabaseUtil.tbl_customer+" SET status='Active' where id="+customerId;
		
	    try {
	    	st1 =conn.prepareStatement(query);
			if(st1.executeUpdate()>0)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	    return false;
	}
	
	public static boolean loginCustomer(String customerId, String password)
	{
		PreparedStatement st1=null;
		String query=null;
		Connection conn=null;
		ResultSet rs = null;
		
		conn = DatabaseUtil.getConnection();
		query = "select count(*) from "+DatabaseUtil.tbl_customer_login+" where USER_ID='"+customerId+"' AND password='"+Login.getHashPassword(password)+"'";
	    try {
	    	st1 =conn.prepareStatement(query);
	    	rs=st1.executeQuery();
	    	rs.next();
			if(rs.getInt(1)>0)
				return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	    return false;
	}
}
