package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.bean.Account;
import com.bean.Customer;
import com.bean.Transaction;
import com.util.DatabaseUtil;
import com.util.DbTransaction;

public class AccountDao {

	public static boolean addAccount(Account a) throws SQLException {
		Connection con = DatabaseUtil.getConnection();
		ResultSet rs = null;
		PreparedStatement ps = null;
		String sql = "insert into " + DatabaseUtil.tbl_account
				+ " values(seq_account_G3.nextval,?,?,?,TO_CHAR(SYSDATE, 'MM-DD-YYYY HH24:MI:SS'),TO_CHAR(SYSDATE, 'MM-DD-YYYY HH24:MI:SS'),0)";
		ps = con.prepareStatement(sql);
		ps.setInt(1, a.getCustomerId());
		ps.setString(2, a.getAccountType());
		ps.setInt(3, a.getAmount());

		int x = ps.executeUpdate();
		if (x > 0) {
			return true;

		}
		return false;
	}

	public static ResultSet viewAccount(int accountId) throws SQLException {
		DbTransaction db = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP", "aja38core", "aja38core",
				"tbl_account_g3");
		Connection con = db.getConnection();
		ResultSet rs = null;
		PreparedStatement ps = null;
		String sql = "select * from tbl_account_g3 where account_id=? ";
		ps = con.prepareStatement(sql);
		ps.setInt(1, accountId);
		rs = ps.executeQuery();

		// System.out.println(rs.getString(3));

		return rs;
	}

	public static int updateAccount(int accountId, String accountType) throws SQLException {
		DbTransaction db = new DbTransaction("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP", "aja38core", "aja38core",
				"tbl_account_g3");
		Connection con = db.getConnection();
		ResultSet rs1 = null;
		PreparedStatement ps = null;
		String sql = "update tbl_account_g3 set account_type=? where account_id=? ";
		ps = con.prepareStatement(sql);

		ps.setString(1, accountType);
		ps.setInt(2, accountId);
		int x = ps.executeUpdate();
		if (x > 0) {
			String sql2 = "select * from tbl_account_g3 where account_id=?";
			ps = con.prepareStatement(sql2);
			ps.setInt(1, accountId);
			rs1 = ps.executeQuery();
		}
		while (rs1.next()) {
			return rs1.getInt("amount");
		}
		return rs1.getInt("amount");

	}

	public static int updateAccount(int accountId, int amount, String AccountOperation, String desc) throws SQLException {
		Connection con = DatabaseUtil.getConnection();
		ResultSet rs1 = null;
		PreparedStatement ps = null;
		if (AccountOperation.equalsIgnoreCase("Deposit")) {
			String sql = "update " + DatabaseUtil.tbl_account + " set amount=amount+? where account_id=?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, amount);
			ps.setInt(2, accountId);
			int x = ps.executeUpdate();
			if (x > 0) {
				Statement stmt=con.createStatement();
				stmt.executeUpdate("INSERT INTO "+DatabaseUtil.tbl_transaction+" values(SEQ_TRANSACTION_G3.nextval,"+accountId+","+amount+",'"+AccountOperation+"','"+desc+"',sysdate)");
				return 1;
			}
			return 0;
		} else if (AccountOperation.equals("Withdraw")) {
			if(Transfer.getAmount(accountId) < amount)
				return -2;
			String sql = "update "+DatabaseUtil.tbl_account+" set amount=amount-? where account_id=?";
			System.out.println(accountId);
			ps = con.prepareStatement(sql);
			ps.setInt(1, amount);
			ps.setInt(2, accountId);
			int x = ps.executeUpdate();
			System.out.println(x);
			if (x > 0) {
				Statement stmt=con.createStatement();
				stmt.executeUpdate("INSERT INTO "+DatabaseUtil.tbl_transaction+" values(SEQ_TRANSACTION_G3.nextval,"+accountId+","+amount+",'"+AccountOperation+"','"+desc+"',sysdate)");
				return 1;
			}
			return 0;
		}
		return 0;
	}
	
	public static ArrayList<Transaction> getTransaction(String accountId, int count)
	{
		ArrayList<Transaction> result=new ArrayList<Transaction>();
		
		PreparedStatement st1 = null;
		String query = null;
		Connection conn = null;
		ResultSet rs = null;

		conn = DatabaseUtil.getConnection();
		if (conn != null) {
			query = "select * from "+DatabaseUtil.tbl_transaction+" where ACCOUNTID="+accountId+" AND rownum <= "+count+" ORDER BY ID DESC";
			try {
				st1 = conn.prepareStatement(query);
				rs = st1.executeQuery();
				while(rs.next())
				{
					Transaction t=new Transaction();
					t.setID(rs.getInt(1));
					t.setACCOUNTID(rs.getInt(2));
					t.setAMOUNT(rs.getInt(3));
					t.setTRANSACTION_TYPE(rs.getString(4));
					t.setDESCRIPTION(rs.getString(5));
					t.setTRANSACTION_DATE(rs.getString(6));
					
					result.add(t);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	public static ArrayList<Transaction> getTransactionByDate(String accountId, String startDate, String endDate)
	{
		ArrayList<Transaction> result=new ArrayList<Transaction>();
		
		PreparedStatement st1 = null;
		String query = null;
		Connection conn = null;
		ResultSet rs = null;
		System.out.println(startDate);

		conn = DatabaseUtil.getConnection();
		if (conn != null) {
			query = "select * from "+DatabaseUtil.tbl_transaction+" WHERE ACCOUNTID="+accountId+" AND TRANSACTION_DATE >= TO_DATE('"+startDate+"', 'mm/dd/yyyy') AND TRANSACTION_DATE <= TO_DATE('"+endDate+"', 'mm/dd/yyyy')";
			try {
				st1 = conn.prepareStatement(query);
				rs = st1.executeQuery();
				while(rs.next())
				{
					Transaction t=new Transaction();
					t.setID(rs.getInt(1));
					t.setACCOUNTID(rs.getInt(2));
					t.setAMOUNT(rs.getInt(3));
					t.setTRANSACTION_TYPE(rs.getString(4));
					t.setDESCRIPTION(rs.getString(5));
					t.setTRANSACTION_DATE(rs.getString(6));
					
					result.add(t);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
}
