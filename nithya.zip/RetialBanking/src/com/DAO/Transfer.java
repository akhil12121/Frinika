package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.util.DatabaseUtil;

public class Transfer {

		
	public static ResultSet getAccount(int accountId) 
	{
		Connection con=DatabaseUtil.getConnection();
		ResultSet rs1,rs2=null;
		PreparedStatement ps1,ps2 = null;
		String sql1="select account_type,customer_id from "+DatabaseUtil.tbl_account+" where account_id=?";
		try {
			ps1=con.prepareStatement(sql1,ResultSet.TYPE_SCROLL_INSENSITIVE,
			        ResultSet.CONCUR_READ_ONLY);
			ps1.setInt(1, accountId);
			rs1=ps1.executeQuery();
			rs1.next();
		String type=rs1.getString(1);
		int cust_id=rs1.getInt(2);
			//System.out.println(type);
			
		String sql2="select account_id from "+DatabaseUtil.tbl_account+" where customer_id=? and account_type not in(?)";
		
		ps2=con.prepareStatement(sql2,ResultSet.TYPE_SCROLL_INSENSITIVE,
		        ResultSet.CONCUR_READ_ONLY);
		ps2.setString(2, type);
		ps2.setInt(1, cust_id);
		rs2=ps2.executeQuery();
		
		return rs2;
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
		
	}
	
	
	public static int Transfer_Amt(int accountId1,int accountId2,int amount,String description)
	{
		Connection con=DatabaseUtil.getConnection();
		PreparedStatement ps,ps1,ps2,ps3,ps4 = null;
		String sql="select amount from "+DatabaseUtil.tbl_account+" where account_id=?";
		String sql1="UPDATE "+DatabaseUtil.tbl_account+" set amount=amount-? where account_id=?";
		String sql2="UPDATE "+DatabaseUtil.tbl_account+" set amount=amount+? where account_id=?";
		String sql3="insert into "+DatabaseUtil.tbl_transaction+" values(SEQ_TRANSACTION_G3.nextval,?,?,?,?,sysdate)";
		String sql4="insert into "+DatabaseUtil.tbl_transaction+" values(SEQ_TRANSACTION_G3.nextval,?,?,?,?,sysdate)";
		try{
			ps=con.prepareStatement(sql);
			ps.setInt(1, accountId1);
			ResultSet rs=ps.executeQuery();
			rs.next();
			int amt=rs.getInt(1);
			if((amt-amount)>0){
			ps1=con.prepareStatement(sql1,ResultSet.TYPE_SCROLL_INSENSITIVE,
			        ResultSet.CONCUR_READ_ONLY);
			ps1.setInt(1, amount);
			ps1.setInt(2, accountId1);
			int count1=ps1.executeUpdate();
			if(count1 >0)
			{
				ps3=con.prepareStatement(sql3,ResultSet.TYPE_SCROLL_INSENSITIVE,
				        ResultSet.CONCUR_READ_ONLY);
				ps3.setInt(1, accountId1);
				ps3.setInt(2, amount);
				ps3.setString(3, "Transfer");
				ps3.setString(4, description);
				ps3.executeUpdate();
				//System.out.println("Transfer");
				ps2=con.prepareStatement(sql2,ResultSet.TYPE_SCROLL_INSENSITIVE,
				ResultSet.CONCUR_READ_ONLY);
				ps2.setInt(1, amount);
				ps2.setInt(2, accountId2);
				int count2=ps2.executeUpdate();
				
				if(count2>0)
				{
					ps4=con.prepareStatement(sql4,ResultSet.TYPE_SCROLL_INSENSITIVE,
					        ResultSet.CONCUR_READ_ONLY);
					ps4.setInt(1, accountId2);
					ps4.setInt(2, amount);
					ps4.setString(3, "Received");
					ps4.setString(4, description);
					ps4.executeUpdate();
					// System.out.println("Received");
				}
				
				return count2;
			}
			}
			
			
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return -1;
	}
	
	
	public static int getCustomerId(int accountId1)
	{
		Connection con=DatabaseUtil.getConnection();
		ResultSet rs1=null;
		PreparedStatement ps1= null;
		String sql="select customer_id from "+DatabaseUtil.tbl_account+" where account_id=?";
		try {
			ps1=con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
			        ResultSet.CONCUR_READ_ONLY);
			ps1.setInt(1, accountId1);
			rs1=ps1.executeQuery();
			rs1.next();
		int cust_id=rs1.getInt(1);
		return cust_id;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return -1;
	}
	
	
	public static int getAmount(int accountId)
	{
		Connection con=DatabaseUtil.getConnection();
		ResultSet rs1=null;
		PreparedStatement ps1= null;
		String sql="select amount from "+DatabaseUtil.tbl_account+" where account_id=?";
		try {
			ps1=con.prepareStatement(sql);
			ps1.setInt(1, accountId);
			rs1=ps1.executeQuery();
			rs1.next();
		int amt=rs1.getInt(1);
		return amt;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return -1;
	}
	
	public static String getAccountType(int accountId)
	{
		Connection con=DatabaseUtil.getConnection();
		ResultSet rs1=null;
		PreparedStatement ps1= null;
		String sql="select account_type from "+DatabaseUtil.tbl_account+" where account_id=?";
		try {
			ps1=con.prepareStatement(sql);
			ps1.setInt(1, accountId);
			rs1=ps1.executeQuery();
			rs1.next();
		String type=rs1.getString(1);
		return type;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}
	
}
