package com.service;

import com.DAO.CustomerDAO;

public class CustomerService {
	public boolean activateCustomer(String customerId, String currentStatus)
	{
		return CustomerDAO.activateCustomer(customerId, currentStatus);
	}
	
	public boolean loginCustomer(String customerId, String password)
	{
		return CustomerDAO.loginCustomer(customerId, password);
	}
}
