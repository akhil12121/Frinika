package com.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import com.DAO.EmployeeLogin;

public class Login {
	
	EmployeeLogin empLogin=new EmployeeLogin();
	public static String getHashPassword(String password)
	{
		//String password = "12345";

        MessageDigest md=null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        md.update(password.getBytes());

        byte byteData[] = md.digest();

        StringBuffer hexString = new StringBuffer();
    	for (int i=0;i<byteData.length;i++) {
    		String hex=Integer.toHexString(0xff & byteData[i]);
   	     	if(hex.length()==1) hexString.append('0');
   	     	hexString.append(hex);
    	}
    	return hexString.toString();
	}
	
	
	public boolean validateLogin(String user,String password)
	{
		return empLogin.validateLogin(user, password);
	}
}