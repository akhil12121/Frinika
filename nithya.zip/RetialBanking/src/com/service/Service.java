package com.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.DAO.AccountDao;
import com.DAO.CreateCustomer;
import com.bean.Account;
import com.bean.Customer;

public class Service {

	public static boolean addCustomer(Customer c) throws SQLException
	{
		return CreateCustomer.addCustomer(c);
	}
	public static ResultSet deleteCustomer(int customer_id) throws SQLException
	{

		return CreateCustomer.deleteCustomer(customer_id);
	}
	public static boolean addAccount(Account a ) throws SQLException
	{
		return AccountDao.addAccount(a);
	}
	public static ResultSet viewAccount(int accountId) throws SQLException
	{
		return AccountDao.viewAccount(accountId);
	}
	public static int updateAccount(int accountId,String accountType) throws SQLException
	{
		return AccountDao.updateAccount(accountId,accountType);
	}
	public static int updateAccount(int accountId,int amount,String AccountOperation,String description) throws SQLException
	{
		return AccountDao.updateAccount(accountId, amount, AccountOperation,description);
	}
}
