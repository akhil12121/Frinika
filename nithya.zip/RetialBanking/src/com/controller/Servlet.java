package com.controller;
import java.sql.*;
import java.io.IOException;

import com.service.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Customer;
import java.sql.*;
/**
 * Servlet implementation class Servlet
 */
@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
	
	
		Customer c= new Customer();
		c.setSSN(Integer.parseInt(request.getParameter("SSN")));
		c.setCustomer_name(request.getParameter("customer_name"));
		c.setPassword(request.getParameter("password"));
		c.setDob(request.getParameter("DOB"));
		System.out.println(c.getDob());
		c.setAddress_line1(request.getParameter("address_line1"));
		c.setAddress_line2(request.getParameter("address_line2"));
		c.setCity(request.getParameter("city"));
		c.setState(request.getParameter("State"));
		
		
		try {
			boolean result=Service.addCustomer(c);
			request.setAttribute("result", result);
			RequestDispatcher rd= request.getRequestDispatcher("Create/CreateResult.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}