package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.EmployeeLogin;
import com.service.Login;
import com.util.DbTransaction;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("emp/index.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String user=request.getParameter("username");
		String password=request.getParameter("password");
		
		//converting password to hashPassword 
		String hash_pass=Login.getHashPassword(password);
		
		//validating user
		Login logEmp=new Login();
		boolean validate=logEmp.validateLogin(user, hash_pass);
		
		//redirecting to home.jsp if user is validated
		
		//System.out.println(""+validate);
		
		if(validate)
		{
			HttpSession session=request.getSession(true);
			session.setAttribute("userId", user);
			session.setAttribute("userType", EmployeeLogin.getEmployeeType(user));
			response.sendRedirect("/RetialBanking/emp/home.jsp");
		}
		else
		{
			
			request.setAttribute("validate", false);
			request.getRequestDispatcher("emp/index.jsp").forward(request, response);
		}
		
	}

}
