package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Account;
import com.service.Service;

/**
 * Servlet implementation class Account1
 */
@WebServlet("/Account1")
public class Account1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Account1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Account a = new Account();
		System.out.println(request.getParameter("customer_id"));
		a.setCustomerId(Integer.parseInt(request.getParameter("customer_id")));
		a.setAccountType(request.getParameter("AccountType"));
		a.setAmount(Integer.parseInt(request.getParameter("Amount")));

		try {
			boolean x =Service.addAccount(a);
			
			request.setAttribute("result", String.valueOf(x));
			request.setAttribute("customerId", request.getParameter("customer_id"));
			RequestDispatcher rd=request.getRequestDispatcher("emp/createAct.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
