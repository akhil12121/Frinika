package com.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.Service;

/**
 * Servlet implementation class Cashier
 */
@WebServlet("/Cashier")
public class Cashier extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Cashier() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text.html");
		int accountId = Integer.parseInt(request.getParameter("account_id"));
		String AccountOperation = request.getParameter("AccountOperation");
		String description = request.getParameter("description");
		int balance = Integer.parseInt(request.getParameter("amount"));
		
		try {
			request.setAttribute("accountId", accountId);
			request.setAttribute("AccountOperation", AccountOperation);
			request.setAttribute("description", description);
			
			if(AccountOperation.equals("Withdraw"))
				request.setAttribute("Amount", -balance);
			else
				request.setAttribute("Amount", balance);

			int result = Service.updateAccount(accountId, balance, AccountOperation,description);

			if (result > 0) {
				request.setAttribute("result", "true");
			}
			else if(result==-2)
			{
				request.setAttribute("result", "amount");
			}
			else {
				request.setAttribute("result", "false");
			}
			RequestDispatcher rd = request.getRequestDispatcher("emp/transaction.jsp");
			rd.forward(request, response);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
