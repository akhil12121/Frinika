package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.CustomerService;

/**
 * Servlet implementation class ActivateCustomer
 */
@WebServlet("/ActivateCustomer")
public class ActivateCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActivateCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/emp/ActivateCustomer.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerService cs=new CustomerService();
		boolean result=cs.activateCustomer(request.getParameter("customerId"), request.getParameter("currentStatus"));
		if(result)
		{
			request.setAttribute("result", "true");
			request.setAttribute("userId", request.getParameter("customerId"));
		}
		else
			request.setAttribute("result", "false");
		request.getRequestDispatcher("/emp/ActivateCustomer.jsp").forward(request, response);
	}

}
