package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.EmployeeLogin;
import com.service.CustomerService;

/**
 * Servlet implementation class CustomerLogin
 */
@WebServlet("/CustomerLogin")
public class CustomerLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerService cs=new CustomerService();
		if(request.getParameter("userId")==null || request.getParameter("userId")=="" || request.getParameter("password")==null || request.getParameter("password")=="")
			request.getRequestDispatcher("index.jsp").forward(request, response);
		if(cs.loginCustomer(request.getParameter("userId"), request.getParameter("password")))
		{
			HttpSession session=request.getSession(true);
			session.setAttribute("userId", request.getParameter("userId"));
			session.setAttribute("userType", "user");
			response.sendRedirect("dashboard.jsp");
		}
		else
		{
			request.setAttribute("result", "false");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

}
