package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.util.DatabaseUtil;

public class DeleteAccountDao {

	static Connection con = null;

	public static int deleteaccount(int accountid) {

		PreparedStatement ps1 = null;

		int count1 = 0;

		try {
			con = DatabaseUtil.getConnection();
			if (con != null) {
				if (Transfer.getAmount(accountid) != 0)
					return -2;
				String psquery1 = "DELETE FROM TBL_account_G3_A WHERE ACCOUNT_ID = ?";

				ps1 = con.prepareStatement(psquery1);
				ps1.setInt(1, accountid);

				count1 = ps1.executeUpdate();
				System.out.println("coun1" + count1);

				if (count1 > 0) {
					return 1;
				}

			}
		} catch (Exception e1) {
			System.out.println(e1);
		} finally {
			DatabaseUtil.closeConnection(con);
		}
		return 0;
	}

}
