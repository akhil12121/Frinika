package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bean.Customer;
import com.util.DatabaseUtil;

public class Delete_customer {

	static Connection con = null;

	public static boolean deletecustomer(int customerid) {

		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		int count1=0;
		int count2=0;
		
		try {
			con = DatabaseUtil.getConnection();
			if (con != null) {

				String psquery1 = "DELETE FROM TBL_CUSTOMER_G3_A WHERE ID= ?";
				String psquery2 =" DELETE FROM TBL_CUSTOMER_LOGIN_G3_A WHERE ID= ?";
                 
				System.out.println("after query");
				
				   ps2 = con.prepareStatement(psquery2);
	                ps2.setInt(1, customerid);
	                 count2 = ps2.executeUpdate();
	                System.out.println("coun2"+ count2);
				
				ps1 = con.prepareStatement(psquery1);
                ps1.setInt(1, customerid);
                 count1 = ps1.executeUpdate();
                System.out.println("coun1"+ count1);
                
             
                
                if(count1>0 && count2>0)
                {
                	return true;
                }
        
			}
		} catch (Exception e1) {
			System.out.println(e1);
		} finally {

			
			DatabaseUtil.closeConnection(con);
		}

		return false;

	}

}
