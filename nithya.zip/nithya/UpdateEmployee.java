package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.Employeee;
import com.bean.Employee;


/**
 * Servlet implementation class UpdateEmployee
 */
@WebServlet("/UpdateEmployee")
public class UpdateEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateEmployee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		int EMPLOYEE_ID=Integer.parseInt(request.getParameter("EMPLOYEE_ID")); 
		String EMPLOYEE_NAME=request.getParameter("EMPLOYEE_NAME");
		String ADDRESS_LINE1=request.getParameter("ADDRESS_LINE1");
		String ADDRESS_LINE2=request.getParameter("ADDRESS_LINE2");
		String CITY=request.getParameter("CITY");
		String STATE=request.getParameter("STATE");
		int AGE=Integer.parseInt(request.getParameter("AGE")); 
		//String TYPE=request.getParameter("TYPE");
		
		
		System.out.println(EMPLOYEE_ID+" "+EMPLOYEE_NAME+" "+ADDRESS_LINE1+" "+ADDRESS_LINE2+" "+CITY+" "+STATE+" "+AGE);		
		Employee e=new Employee();
		e.setEmployee_id(EMPLOYEE_ID);
		e.setEmployee_name(EMPLOYEE_NAME);
		e.setAddress_line1(ADDRESS_LINE1);
		e.setAddress_line2(ADDRESS_LINE2);
		e.setCity(CITY);
		e.setState(STATE);
		e.setAge(AGE);
		//e.setType(TYPE);
	    System.out.println("inside servlet class");
		int status=Employeee.update(e);
		System.out.println(status);
		if(status>0)
		{
			request.setAttribute("status", 1);
			request.getRequestDispatcher("RetialBankingWebContent/emp/blank2.jsp").forward(request, response);
		}
		else
		{ 
			 out.println("Sorry! unable to update record");  
	}
		 out.close();
	
	}
		
		
		
	}


