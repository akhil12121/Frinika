package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.bean.Employee;
import com.util.DatabaseUtil;
public class Employeee {		static Connection conn=null;
		static Statement st=null;
		static PreparedStatement pst=null;
		static ResultSet rs=null;
		public static int update(Employee e)
		{
			int status=0;
			try{
				conn=DatabaseUtil.getConnection();
				
				String query="update TBL_employee_G3 set name=?,address_line1=?,address_line2=?, city=?,state=?,age=? where id=?";
				pst=conn.prepareStatement(query);
				System.out.println("inside the dao class");
				
				pst.setString(1, e.getEmployee_name());
				pst.setString(2,e.getAddress_line1());
				pst.setString(3, e.getAddress_line2());
				pst.setString(4, e.getCity());
				pst.setString(5, e.getState());
				pst.setInt(6,e.getAge());
				//pst.setString(7, e.getType());
				pst.setInt(7, e.getEmployee_id());
				status=pst.executeUpdate();
				
				System.out.println("the query is executed");
			    System.out.println(status);
			}catch(SQLException s)
			{
				s.printStackTrace();
			}catch(Exception e1)
			{
				e1.printStackTrace();
			}
//			finally{
//				DatabaseUtil.closeConnection(conn);
//				DatabaseUtil.closeStatement(pst);
//			}
			return status;
		}
		

	}

